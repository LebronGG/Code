    Populating the interactive namespace from numpy and matplotlib
    Creating networks and loading parameters
    

    找到人脸数目为：26
    [[3.78578627e+03 1.75625163e+03 3.91348894e+03 1.92063227e+03
      9.99999642e-01]
     [1.75666426e+03 1.70658581e+03 1.88091997e+03 1.86923668e+03
      9.99998569e-01]
     [4.10387722e+03 1.78279030e+03 4.23137293e+03 1.92979681e+03
      9.99998331e-01]
     [3.12427180e+03 1.78017954e+03 3.24247112e+03 1.93466346e+03
      9.99996543e-01]
     [2.87642055e+03 1.58282812e+03 2.98588314e+03 1.71531231e+03
      9.99995828e-01]
     [3.51882444e+03 1.60922769e+03 3.62223210e+03 1.73073257e+03
      9.99995589e-01]
     [1.10797535e+03 1.56795252e+03 1.21145141e+03 1.69813989e+03
      9.99994159e-01]
     [2.84305850e+03 1.73321096e+03 2.96350856e+03 1.88323201e+03
      9.99994040e-01]
     [1.39447308e+03 1.71772511e+03 1.52587948e+03 1.87793268e+03
      9.99991298e-01]
     [3.81029336e+03 1.58236678e+03 3.92264618e+03 1.72536179e+03
      9.99987006e-01]
     [7.76825892e+02 1.59577791e+03 8.84096366e+02 1.72341709e+03
      9.99986410e-01]
     [3.23245904e+03 1.59943126e+03 3.32939958e+03 1.73377311e+03
      9.99975801e-01]
     [1.05729083e+03 1.69624629e+03 1.18583955e+03 1.85969917e+03
      9.99975204e-01]
     [4.04564740e+03 1.59323909e+03 4.15780409e+03 1.73009672e+03
      9.99973536e-01]
     [3.43773328e+03 1.78038555e+03 3.56139636e+03 1.93106535e+03
      9.99968171e-01]
     [2.48296004e+03 1.62499576e+03 2.60957815e+03 1.78264625e+03
      9.99964118e-01]
     [2.10295168e+03 1.70034678e+03 2.23958131e+03 1.88044362e+03
      9.99960780e-01]
     [2.63014639e+03 1.61706851e+03 2.72836303e+03 1.74453298e+03
      9.99958873e-01]
     [1.44018201e+03 1.59701212e+03 1.55352306e+03 1.72760752e+03
      9.99943018e-01]
     [2.06102367e+03 1.57531271e+03 2.16581533e+03 1.70914732e+03
      9.99752223e-01]
     [2.35459423e+03 1.59684597e+03 2.44350041e+03 1.71171943e+03
      9.97768998e-01]
     [6.65235651e+02 1.70122045e+03 8.18152720e+02 1.89910636e+03
      9.95836973e-01]
     [4.20448384e+02 1.90271402e+03 4.59992690e+02 1.94750846e+03
      9.88838553e-01]
     [3.30992451e+02 1.81034623e+03 3.57707860e+02 1.84026130e+03
      9.85650122e-01]
     [4.54210581e+03 1.81030366e+03 4.55738572e+03 1.82883801e+03
      9.71735537e-01]
     [3.81700029e+03 3.01797742e+03 3.83785429e+03 3.04374207e+03
      7.14848220e-01]]
    
    
    [3785 1756 3913 1920]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_4.png)


    [1756 1706 1880 1869]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_6.png)


    [4103 1782 4231 1929]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_8.png)


    [3124 1780 3242 1934]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_10.png)


    [2876 1582 2985 1715]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_12.png)


    [3518 1609 3622 1730]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_14.png)


    [1107 1567 1211 1698]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_16.png)


    [2843 1733 2963 1883]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_18.png)


    [1394 1717 1525 1877]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_20.png)


    [3810 1582 3922 1725]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_22.png)


    [ 776 1595  884 1723]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_24.png)


    [3232 1599 3329 1733]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_26.png)


    [1057 1696 1185 1859]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_28.png)


    [4045 1593 4157 1730]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_30.png)


    [3437 1780 3561 1931]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_32.png)


    [2482 1624 2609 1782]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_34.png)


    [2102 1700 2239 1880]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_36.png)


    [2630 1617 2728 1744]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_38.png)


    [1440 1597 1553 1727]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_40.png)


    [2061 1575 2165 1709]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_42.png)


    [2354 1596 2443 1711]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_44.png)


    [ 665 1701  818 1899]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_46.png)


    [ 420 1902  459 1947]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_48.png)


    [ 330 1810  357 1840]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_50.png)


    [4542 1810 4557 1828]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_52.png)


    [3817 3017 3837 3043]
    (96, 96, 3)
    


![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_54.png)



![png](https://github.com/ShyBigBoy/face-detection-mtcnn/raw/master/result-preview/multi-faces/output_0_55.png)

